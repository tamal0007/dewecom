﻿<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	
	 public function index()
            {
           
        $data = array();
        $data['title'] = 'Add Product';
        $data['admin_main_content'] =$this->load->view('admin_pages/pages/product/product_add_view','', TRUE);
        $this->load->view('admin_pages/admin_master', $data);
            }
     public function model_entry()
	{
        $txt_md=$this->input->post('txt_md');
        $txt_icn=$this->input->post('txt_icn');
        $txt_mtkey=$this->input->post('txt_mtkey');
        $txt_ds=$this->input->post('txt_ds');

        
	$data_arr = array(
			'model_name'   => $txt_md,
			'inserted_by'   => 0,
			'insert_date'	=>date('YYYY-mm-dd'),
            'updated_by'    =>0,
            'update_date'   =>0,
            'status_active' =>1,
			'is_deleted'	=>0,
			);
			
	$this->db->insert('model_info',$data_arr);

	}
	}