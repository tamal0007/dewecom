<?php

class Sub_Category extends CI_Controller{
    //put your code here
    public function index()
            {
         
        $data = array();
        $data['title'] = 'Add Sub Category';
        $data['admin_main_content'] =$this->load->view('admin_pages/pages/sub_category/sub_category_add_view','', TRUE);
        $this->load->view('admin_pages/admin_master', $data);
            }
    public function view()
            {

                $data = array();
                $data['title'] = 'View Category';
                $cdata = array();
                $cdata['select_all_category']= $this->Category_Model->select_all_category_info();
                $data['admin_main_content'] = $this->load->view('admin_pages/pages/category/view',$cdata, TRUE);
                $this->load->view('admin_pages/admin_master', $data);
            }
            
        public function category_entry()
	{
        $txt_cname=$this->input->post('txt_cname');
        $txt_icn=$this->input->post('txt_icn');
        
	$data_arr = array(
			'category_name'   => $txt_cname,
			'inserted_by'   => 0,
			'insert_date'	=>date('YYYY-mm-dd'),
            'updated_by'    =>0,
            'update_date'   =>0,
            'status_active' =>1,
			'is_deleted'	=>0,
			);
			
	$this->db->insert('category_info',$data_arr);

	}
}
