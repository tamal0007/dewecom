<?php

class Store_Entry extends CI_Controller {

    //put your code here
     public function __construct() {
        parent::__construct();
        $res=$this->session->userdata('id');
        if ($res == NULL) {
            redirect('admin', 'refresh');
        }
    }
    
    public function index() {

        $data = array();
        $cdata = array();
        $data['title'] = 'Add Brand';
        $cdata['select_all_pub_category'] = $this->Category_Model->select_all_published_category_info();
        $data['admin_main_content'] = $this->load->view('admin_pages/pages/store/store_entry_view',$cdata, TRUE);
        $this->load->view('admin_pages/admin_master', $data);
    }

    
    public function fn_save() {
        
      $data=array();
        
        
        //        start
                $this->load->library('upload');
                $config['upload_path']= 'upload_image/icons/brand_icon/';
                $config['allowed_types'] = 'gif|jpg|png';
              //$config['max_size']= '200';
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $error = '';
                $fdata = array();
                if (!$this->upload->do_upload('file_logo')) {
                    $error = $this->upload->display_errors();
                    echo $error;
                    /* exit();*/
                } else {
                    $fdata = $this->upload->data();
                    $data['brand_icon'] = $config['upload_path'] . $fdata['file_name'];      
                }
        //end
        

        $txt_store_name = $this->input->post('txt_store_name');
        $txt_store_slogan= $this->input->post('txt_store_slogan');
        $txt_store_address= $this->input->post('txt_store_address');
        $txt_store_lat= $this->input->post('txt_store_lat');
        $txt_store_lang= $this->input->post('txt_store_lang');
        $file_logo= $this->input->post('file_logo');
        $data_arr = array(
            'store_name' => $txt_store_name,
            'store_slogan' => $txt_store_slogan,
            'store_address' => $txt_store_address,
            'store_lat' => $txt_store_lat,
            'store_lang' => $txt_store_lang,
            'store_logo' => 0,
            'insert_time' => date('YYYY-mm-dd'),
            'updated_by' => 0,
            'update_time' => 0,
            'is_active' => 1,
            'is_delete' => 0,
        );
$t_data = $data_arr+$data;
//         echo '<pre>';
//        print_r($t_data);
//        exit(); 
        $this->db->insert('brand', $t_data);
         $sdata = array();
        $sdata['message'] = 'Succesfully Save Brand info';
        $this->session->set_userdata($sdata);
        redirect('Brand');
    }
    
    
    
    
     public function view() {

        $data = array();
        $data['title'] = 'View Brand';
        $cdata = array();
        $cdata['select_all_brand'] = $this->Brand_Model->select_all_brand_info();
        $data['admin_main_content'] = $this->load->view('admin_pages/pages/brand/brand_list_view', $cdata, TRUE);
        $this->load->view('admin_pages/admin_master', $data);
    }
    
    
    
    public function brand_entry() {
        $txt_bname = $this->input->post('txt_bname');
        $txt_icn = $this->input->post('txt_icn');

        $data_arr = array(
            'brand_name' => $txt_bname,
            'inserted_by' => 0,
            'insert_date' => date('YYYY-mm-dd'),
            'updated_by' => 0,
            'update_date' => 0,
            'status_active' => 1,
            'is_deleted' => 0,
        );

        $this->db->insert('brand_info', $data_arr);
    }
    
    
     public function inactive($brand_id) {
         
        $this->Brand_Model->inactive_brand_info($brand_id);
        redirect('Brand/view');
    }

    public function active($brand_id) {
        $this->Brand_Model->active_brand_info($brand_id);
        redirect('Brand/view');
    }

    public function edit_brand($brand_id) {
        $data = array();
        $data['title'] = 'Edit Brand';
        $cdata = array();
        $cdata['select_brand_by_id'] = $this->Brand_Model->select_brand_by_id($brand_id);
         $cdata['select_all_pub_category'] = $this->Category_Model->select_all_published_category_info();

//         echo '<pre>';
//         print_r($cdata);
//         exit();

        $data['admin_main_content'] = $this->load->view('admin_pages/pages/brand/brand_edit_view', $cdata, TRUE);
        $this->load->view('admin_pages/admin_master', $data);
    }

    public function update_brand() {

        $data = array();
        $id = $this->input->post('id', TRUE);
        $data['c_name'] = $this->input->post('category_name', TRUE);
        $data['c_description'] = $this->input->post('category_description', TRUE);
        $data['c_status'] = $this->input->post('status', TRUE);
        $this->Category_Model->update_category_info($data, $id);
        $sdata = array();
        $sdata['message'] = "Successfully Update Category";
        $this->session->set_userdata($sdata);
        redirect('Category/view');
    }

    public function delete_brand($brand_id) {

        $this->Brand_Model->delete_brand_by_id($brand_id);
        redirect('Brand/view');
    }

}
